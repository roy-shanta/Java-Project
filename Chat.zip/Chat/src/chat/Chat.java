
package chat;

/**
 *
 * @author Shanta
 */
public class Chat {   
    public static void main(String[] args) {
    }
    
}
